<?php
return array(
	//'配置项'=>'配置值'
//	//让页面显示追踪日志信息
//    	'SHOW_PAGE_TRACE'   => true,
) 
;