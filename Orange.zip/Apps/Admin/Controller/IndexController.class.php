<?php

namespace Admin\Controller;

/**
 * 后台首页
 *
 * @author NENER
 *        
 */
class IndexController extends BaseController {
	public function index() {
		$this->display ();
	}
}