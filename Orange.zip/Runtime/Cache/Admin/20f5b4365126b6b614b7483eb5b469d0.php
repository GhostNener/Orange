<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<title>大橘子-管理后台</title>
	<!-- Bootstrap Core CSS -->
	<link href="/Orange/Public/css/bootstrap.min.css" rel="stylesheet">
	<link href="/Orange/Public/css/normalize.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="/Orange/Public/css/juzi.css" rel="stylesheet">

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="http://cdn.bootcss.com/respond./Orange/Public/js/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>

<body>

	<!-- 页身 -->
	<div id="wrap">
		<!-- 导航 -->
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand">管理后台</a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

					<ul class="nav navbar-nav">
						<li>
							<a href="<?php echo U('/Admin/Index');?>">首页</a>
						</li>
						<li>
							<a href="<?php echo U('/Admin/GoodsCategory');?>">分类</a>
						</li>
						<li>
							<a href="javascript:alert('逗比');">商品</a>
						</li>
						<li>
							<a href="#">发现</a>
						</li>
						<li>
							<a href="#">礼品</a>
						</li>
						<li>
							<a href="#">活动</a>
						</li>
					</ul>

					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<span><?php echo ($usermodel["Nick"]); ?></span>
								&nbsp
								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<li>
									<a href="<?php echo U('/');?>">网站首页</a>
								</li>
								<li>
									<a href="<?php echo U('/Usercenter/User/logout');?>">退出</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>

			</div>
			<!-- /.container-fluid -->
		</nav>

<div class="container">
	<div class="col-md-3">
		<label>分类管理</label>
		<ul class="list-group">
			<a class="list-group-item" href="<?php echo U('/Admin/GoodsCategory');?>">商品分类</a>
		</ul>
		<label>词库管理</label>
		<ul class="list-group">
			<a class="list-group-item" href="<?php echo U('GoodsCategoryKeyword/tempSearchKeyList');?>">搜索关键字</a>
			<a class="list-group-item" href="<?php echo U('GoodsCategoryKeyword/tempCateKeyList');?>">分类关键字</a>
			<a class="list-group-item save" href="javascript:void(0);" action="<?php echo U('CategoryDic/crate');?>">生成词库</a>
		</ul>
		<label>分类词库</label>
		<ul class="list-group">
			<?php if(is_array($catelist)): foreach($catelist as $key=>$v): ?><a class="list-group-item" href="<?php echo U('GoodsCategoryKeyword/index',array('CategoryId'=>$v['Id']));?>"><?php echo ($v["Title"]); ?></a><?php endforeach; endif; ?>

		</ul>
	</div>

	
	<div class="col-md-9">
		<div class="panel panel-default">
			<div class="panel-heading">
				<button class="btn btn-success" data-toggle="modal" data-target="#addModal">添加</button>
			</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped">
						<thead>
							<th>编号</th>
							<th>分类</th>
							<th width="400">关键字</th>
							<th>状态</th>
							<th>操作</th>
						</thead>
						<tbody>
							<?php if(is_array($list)): foreach($list as $key=>$v): ?><tr>
									<td><?php echo ($v["Id"]); ?></td>
									<td><?php echo ($v["Title"]); ?></td>
									<td><?php echo ($v["Keyword"]); ?></td>
									<td><?php echo ($v["Status"]); ?></td>
									<td>
										<a class="btn btn-danger btn-small save" action="<?php echo U(del,array('Id'=>$v['Id'], 'CategoryId'=>$v['CategoryId']));?>">删除</a>
										<a class="btn btn-primary btn-small edit" action="<?php echo U(update,array('Id'=>$v['Id']));?>" modaltitle="编辑关键字">编辑</a>
									</td>
								</tr><?php endforeach; endif; ?>
						</tbody>
					</table>
				</div>

				<div class="page pull-right"><?php echo ($page); ?></div>

			</div>
		</div>
	</div>
	<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">
						<span aria-hidden="true">&times;</span>
						<span class="sr-only">Close</span>
					</button>
					<h4 class="modal-title hightlight" id="myModalLabel">添加关键字</h4>
				</div>

				<form class="form-horizontal" action="<?php echo U('save');?>" method="POST" onsubmit="return ajaxsubmit()">
					<div class="modal-body">

						<input type="hidden" class="form-control " name="modif" value="add">
						<input type="hidden" class="form-control " name="Id" value="<?php echo ($model["Id"]); ?>">
						<input type="hidden" class="form-control " name="Status" value="10">
						<input type="hidden" class="form-control " name="CategoryId" value="<?php echo ($cmodel['Id']); ?>">

						<div class="form-group">
							<label class="col-sm-2 control-label">关键字</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="Keyword" placeholder="你填啊" required></div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal">关闭</button>
						<button type="reset" class="btn btn-warning">清空</button>
						<button type="submit" class="btn btn-primary">保存</button>
					</div>
				</form>

			</div>
		</div>
	</div>

</div>

	</div>
	<script src="/Orange/Public/js/jquery-1.8.0.min.js"></script>
	<script src="/Orange/Public/js/bootstrap.min.js"></script>
	<script src="/Orange/Public/js/juzi.js"></script>


<script type="text/javascript">
		//表单提交
		function ajaxsubmit(){
			var form = $("form");
			$('button[type$=submit]').attr('disabled' ,'disabled');
			$('button[type$=submit]').text('等啊等...');
			$.ajax({
                type: form.attr("method"),
                url: form.attr("action"),
                data: form.serialize(),
                error: function(request) {
					showerrormsg('网络连接失败',100,1000);
                },
                success: function(data) {
                    if (data.status != 1) {
						showerrormsg(data.info,100,1000);
						$('button[type$=submit]').removeAttr('disabled');
						$('button[type$=reset]').click();
						$('button[type$=submit]').text('保存');

                    }
                    else{
						showsuccessmsg(data.info,100,1000);
						setTimeout(function(){
							window.location.href=window.location.href;
						},500);                  	
                    }
                }
            });
            return false;
		}
		
		//异步获取数据
		$('.edit').click(function () {
			var a = $(this);
			$.ajax({
				type:'get',
				url: a.attr('action'),
				beforeSend: loading(),
				error: function(request) {
					showsuccessmsg('网络连接失败',100,1000);
				},
				success: function(data) {
					var result = eval("("+data+")");
					
					if(result.status != 1){
						showerrormsg(data.info,100,1000);
						return false;
					}
					else{

						//填充数据
						for(var p in result.data){        
		       				$('input[name$='+p+']').val(result.data[p]);
		       				$('select[name$='+p+']').children().each(function () {
		       					if ($(this).attr('value')==result.data[p]) {
		       						$(this).attr('selected','selected');
		       						return;
		       					};
		       				});
						}

						$('input[name$=modif]').val(result.method);
						$('#addModal').modal('show');
						$('#myModalLabel').text(a.attr('modaltitle'));
					}
				},
				complete: function() {
					$("#load").remove();
				}

			});
			
		});

		var lock = false;
		$('.save').click(function () {
			$(this).removeClass('save');
			$(this).addClass('disabled');
			$(this).attr("disabled", "disabled"); 
			if (lock) {
				return;
			};
			$.ajax({
				type:'get',
				url:$(this).attr('action'),
				beforeSend: function(){
					loading();
					lock = true;
				},
				error: function(request) {
					showerrormsg('网络连接失败',100,1000);

				},
				success: function(data) {
					showsuccessmsg(data.info,100,1000);
						setTimeout(function(){
							window.location.href=window.location.href;
						},1000);                  	
				},
				complete: function() {
					$("#load").remove();
				}

				});
		});

		function loading() { 
					$("body").append('<div  id="load" style="z-index:10; position:fixed; left:45%; top:30%"><img src="/Orange/Public/Img/loading.gif" /></div>'); 
				}
	</script>

</body>

</html>