<?php if (!defined('THINK_PATH')) exit();?><!-- 首页通用两栏式模板 -->
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="贵州财经大学-二手交易-以物换物-服务平台-c2c">
	<meta name="author" content="橘子团队">
	<title>大橘子-贵财最大的二手交易平台</title>
	<!-- Bootstrap Core CSS -->
	<link href="/Orange/Public/css/bootstrap.min.css" rel="stylesheet">
	<link href="/Orange/Public/css/normalize.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="/Orange/Public/css/juzi.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Orange/Public/Img/favicon.png"
	type="image/x-icon" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->

	
</head>
<body>
	<!-- 页身 -->
	<div id="wrap">
		<!-- 导航 -->
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">logo 大橘子</a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="active">
							<a href="<?php echo U('Home/Index/index');?>">首页</a>
						</li>
						<li>
							<a href="#">发现</a>
						</li>
						<li>
							<a href="#">
								礼品
								<span class="navbar-new"></span>
							</a>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search" action="<?php echo U('Home/Index/searchgoods');?>" method="get">
						<div class="input-group">
							<input type="text" class="form-control " id="text" placeholder="搜索商品" name="wd" value="<?php echo ($test); ?>">
							<div class="input-group-btn">
								<button type="submit" class="btn btn-default btn-expend">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
							<!-- /btn-group -->
						</div>
						<!-- /input-group -->
					</form>
					<!-- 登录标识 -->
					<?php if($usermodel == null): ?><ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo U('Usercenter/User/index');?>" >登录</a>
							</li>
							<li>
								<a href="<?php echo U('Usercenter/User/regist');?>">注册</a>
							</li>
						</ul>
						<?php else: ?>
						<!-- 登录状态 -->
						<ul class="nav navbar-nav navbar-right nickul">
							<li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">

									<span class="nickname">
										<img class="img-circle" src="http://hhhhold.com/20x20">&nbsp;<?php echo ($usermodel['Nick']); ?>&nbsp;</span>
									&nbsp
									<span class="caret"></span>
									&nbsp
									<span class="badge">3</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">
											<span class="badge pull-right">3</span>
											未读消息
										</a>
									</li>
									<li>
										<a href="<?php echo U('Usercenter/Index/index');?>">个人中心</a>
									</li>
									<li>
										<a href="#">心愿单</a>
									</li>
									<li>
										<a href="#">充值</a>
									</li>
									<li class="divider"></li>
									<li>
										<a href="<?php echo U('Usercenter/User/logout');?>">退出用户</a>
									</li>
								</ul>
							</li>
						</ul><?php endif; ?>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>

<!-- 内容 -->
<div id="main" class="container">
	<!-- 发布按钮 -->
	<div class="navbar-fixed-bottom fixed-expand">
		<button id="creategoods" url="<?php echo U('Home/Goods/add');?>" type="button" class="btn btn-orange btnpublish" data-toggle="tooltip" data-placement="top" title="发布商品">
			<span class="glyphicon glyphicon-plus"></span>
		</button>
	</div>
	<div class="row">
		<!-- 商品展示 -->
		
	<div class="col-md-9">
		<div class="row carousel-holder">
			<div class="col-md-12" >
				<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<?php $__FOR_START_13235__=0;$__FOR_END_13235__=count($topimg);for($i=$__FOR_START_13235__;$i < $__FOR_END_13235__;$i+=1){ if($i == 0): ?><li data-target="#carousel-example-generic" data-slide-to="<?php echo ($i); ?>" class="active"></li>
								<?php else: ?>
								<li data-target="#carousel-example-generic" data-slide-to="<?php echo ($i); ?>"></li><?php endif; } ?>
					</ol>
					<div class="carousel-inner">
						<?php $__FOR_START_15728__=0;$__FOR_END_15728__=count($topimg);for($i=$__FOR_START_15728__;$i < $__FOR_END_15728__;$i+=1){ if($i == 0): ?><div class="item active">
									<a href="<?php echo ($topimg[$i]['Href']); ?>" title="<?php echo ($topimg[$i]['Title']); ?>">
										<?php if(checkfile_exists($topimg[$i]['ImgURL']) == 1): ?><img class="slide-image" src="/Orange<?php echo ($topimg[$i]['ImgURL']); ?>" height="300" width="800" alt="<?php echo ($topimg[$i]['Title']); ?>">
											<?php else: ?>
											<img class="slide-image" src="/Orange<?php echo getdefaultimg(2);?>" height="300" width="800" alt="<?php echo ($topimg[$i]['Title']); ?>"><?php endif; ?>
									</a>
								</div>
								<?php else: ?>
								<div class="item">
									<a href="<?php echo ($topimg[$i]['Href']); ?>" title="<?php echo ($topimg[$i]['Title']); ?>">
										<?php if(checkfile_exists($topimg[$i]['ImgURL']) == 1): ?><img class="slide-image" src="/Orange<?php echo ($topimg[$i]['ImgURL']); ?>" height="300" width="800" alt="<?php echo ($topimg[$i]['Title']); ?>">
											<?php else: ?>
											<img class="slide-image" src="/Orange<?php echo getdefaultimg(2);?>" height="300" width="800" alt="<?php echo ($topimg[$i]['Title']); ?>"><?php endif; ?>
									</a>
								</div><?php endif; } ?>
					</div>
					<a class="left carousel-control" href="#carousel-example-generic"  data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left"></span>
					</a>
					<a class="right carousel-control" href="#carousel-example-generic"  data-slide="next">
						<span class="glyphicon glyphicon-chevron-right"></span>
					</a>
				</div>
			</div>

		</div>

		<!-- 热门 -->
		<div class="row">
			<div class="col-sm-12">
				<h4>热门</h4>
			</div>
			<!-- 商品列表 -->
			<?php if(is_array($toplist)): $i = 0; $__LIST__ = $toplist;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="col-sm-4">
					<a href="<?php echo U('Home/Index/showgoods',array('Id'=> $v['Id']));?>" target="_blank" class="thumbnail ">
						<?php if(checkfile_exists($v['ThumbURL']) == 1): ?><img src="/Orange<?php echo ($v['ThumbURL']); ?>" alt="<?php echo ($v['Title']); ?>">
							<?php else: ?>
							<img src="/Orange<?php echo getdefaultimg(1);?>" alt="<?php echo ($v['Title']); ?>"><?php endif; ?>
						<div class="caption">
							<h4 class="pull-right message"><?php echo ($v['TradeWayTxt']); ?></h4>
							<p>
								<img src="/Orange<?php echo ($v['avatarURL']); ?>" alt="头像" class="img-circle">
								<span><?php echo ($v['Nick']); ?></span>
							</p>
							<p><?php echo ($v['Title']); ?></p>
						</div>
						<div class="ratings">
							<h4 class="pull-right message">浏览 <?php echo ($v['Views']); ?></h4>
							<h4 class="pull-right message">评论 <?php echo ($v['CommentCount']); ?>&nbsp</h4>
							<h3>
								<?php echo ($v['Price']); ?>.00
								<?php if($v['Price'] < 10000): if($v['CostPrice'] < 10000): ?><span><?php echo ($v['CostPrice']); ?>.00</span><?php endif; endif; ?>
							</h3>
						</div>
					</a>
				</div><?php endforeach; endif; else: echo "$empty" ;endif; ?>
		</div>

		<hr>
		<!--记得分隔符-->

		<!-- 最新 -->
		<div class="row">
			<div class="col-sm-12">
				<h4>最新</h4>
			</div>

			<!-- 商品列表 -->
			<?php if(is_array($newlist)): $i = 0; $__LIST__ = $newlist;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="col-sm-4">
					<a href="<?php echo U('Home/Index/showgoods',array('Id'=> $v['Id']));?>" target="_blank" class="thumbnail ">
						<?php if(checkfile_exists($v['ThumbURL']) == 1): ?><img src="/Orange<?php echo ($v['ThumbURL']); ?>" alt="<?php echo ($v['Title']); ?>">
							<?php else: ?>
							<img src="/Orange<?php echo getdefaultimg(1);?>" alt="<?php echo ($v['Title']); ?>"><?php endif; ?>
						<div class="caption">
							<h4 class="pull-right message"><?php echo ($v['TradeWayTxt']); ?></h4>
							<p>
								<img src="/Orange<?php echo ($v['avatarURL']); ?>" alt="头像" class="img-circle">
								<span><?php echo ($v['Nick']); ?></span>
							</p>
							<p><?php echo ($v['Title']); ?></p>
						</div>
						<div class="ratings">
							<h4 class="pull-right message">浏览 <?php echo ($v['Views']); ?></h4>
							<h4 class="pull-right message">评论 <?php echo ($v['CommentCount']); ?>&nbsp</h4>
							<h3>
								<?php echo ($v['Price']); ?>.00
								<?php if($v['Price'] < 10000): if($v['CostPrice'] < 10000): ?><span><?php echo ($v['CostPrice']); ?>.00</span><?php endif; endif; ?>
							</h3>
						</div>
					</a>
				</div><?php endforeach; endif; else: echo "$empty" ;endif; ?>
		</div>

		<hr>
		<!--记得分隔符-->

		<!-- 猜你喜欢 -->
		<div class="row">
			<div class="col-sm-12">
				<h4>猜你喜欢</h4>
			</div>

			<!-- 商品列表 -->
			<?php if(is_array($likelist)): $i = 0; $__LIST__ = $likelist;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="col-sm-4">
					<a href="<?php echo U('Home/Index/showgoods',array('Id'=> $v['Id']));?>" target="_blank" class="thumbnail ">
						<?php if(checkfile_exists($v['ThumbURL']) == 1): ?><img src="/Orange<?php echo ($v['ThumbURL']); ?>" alt="<?php echo ($v['Title']); ?>">
							<?php else: ?>
							<img src="/Orange<?php echo getdefaultimg(1);?>" alt="<?php echo ($v['Title']); ?>"><?php endif; ?>
						<div class="caption">
							<h4 class="pull-right message"><?php echo ($v['TradeWayTxt']); ?></h4>
							<p>
								<img src="/Orange<?php echo ($v['avatarURL']); ?>" alt="头像" class="img-circle">
								<span><?php echo ($v['Nick']); ?></span>
							</p>
							<p><?php echo ($v['Title']); ?></p>
						</div>
						<div class="ratings">
							<h4 class="pull-right message">浏览 <?php echo ($v['Views']); ?></h4>
							<h4 class="pull-right message">评论 <?php echo ($v['CommentCount']); ?>&nbsp</h4>
							<h3>
								<?php echo ($v['Price']); ?>.00
								<?php if($v['Price'] < 10000): if($v['CostPrice'] < 10000): ?><span><?php echo ($v['CostPrice']); ?>.00</span><?php endif; endif; ?>
							</h3>
						</div>
					</a>
				</div><?php endforeach; endif; else: echo "$empty" ;endif; ?>
		</div>
	</div>

		<!-- 功能菜单 -->
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-body">
					<?php if($usermodel == null): ?><a href="<?php echo U('Usercenter/User/index');?>" class="btn btn-orange btn-lg btn-block">打卡签到</a>
						<?php else: ?>
						<?php if($isclockin == 1): ?><button  class="btn btn-orange btn-lg btn-block disabled">已连续打卡 <?php echo getclockincount(null);?> 天</button>
							<?php else: ?>
							<form id="clockinform" action="<?php echo U('Home/Index/clockin');?>" method="post" onsubmit="return ajaxclockin()">
								<button id="clockinbtn"  type="submit" class="btn btn-orange btn-lg btn-block" data-loading-text="签到中..." autocomplete="off">打卡签到</button>
							</form><?php endif; endif; ?>

					<!-- 商品分类 -->
					<div class="sideitemnav">
						<h4>商品分类</h4>
						<hr>
						<ul class="list-group">
							<?php if(is_array($clist)): foreach($clist as $key=>$v): ?><a href="<?php echo U('Home/Index/cggoods',array('Id'=> $v['Id']));?>" class="list-group-item">
									<span class="badge"><?php echo ($v['Hot']); ?></span>
									<?php echo ($v['Title']); ?>
								</a><?php endforeach; endif; ?>
						</ul>
					</div>
					<!--/.sideitemnav-->

					<!-- 热门活动 -->
					<div class="sideitemnav">
						<h4>热门活动</h4>
						<?php if(is_array($hotactivity)): $i = 0; $__LIST__ = $hotactivity;if( count($__LIST__)==0 ) : echo "$emptyact" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><hr>
							<div class="media">
								<a class="pull-left" href="#">
									<img class="media-object" src="/Orange<?php echo ($v['ThumURL']); ?>" alt="<?php echo ($v['Title']); ?>"></a>
								<div class="media-body">
									<h5 class="media-heading"><?php echo ($v['Title']); ?></h5>
									<p><?php echo ($v['Presentation']); ?></p>
									<a class="btn btn-success">参与活动</a>

								</div>
							</div><?php endforeach; endif; else: echo "$emptyact" ;endif; ?>
					</div>
					<!--/.sideitemnav-->

					<!-- 排行榜 -->
					<div class="sideitemnav">
						<h4>排行榜</h4>
						<hr>
						<ul id="myTab" class="nav nav-tabs">
							<li class="active">
								<a href="#tab1" data-toggle="tab">签到狂人</a>
							</li>
							<li>
								<a href="#tab2" data-toggle="tab">大富豪</a>
							</li>
						</ul>
						<div id="myTabContent" class="tab-content">
							<div class="tab-pane fade in active" id="tab1">
								<!-- 用户列表 -->
								<div class="tabuser">
									<a href="#">
										<img src="http://hhhhold.com/40x40" alt="头像" class="img-circle">
										<span>乔布斯</span>
									</a>
									<span class="info pull-right">
										签到&nbsp
										<span class="importinfo">50</span>
										&nbsp天
									</span>
								</div>
								<!--用户列表-->

								<div class="tabuser">
									<a href="#">
										<img src="http://hhhhold.com/40x40" alt="头像" class="img-circle">
										<span>乔布斯</span>
									</a>
									<span class="info pull-right">
										签到&nbsp
										<span class="importinfo">50</span>
										&nbsp天
									</span>
								</div>
								<!--用户列表-->
							</div>

							<div class="tab-pane fade" id="tab2">
								<!-- 用户列表 -->
								<div class="tabuser">
									<a href="#">
										<img src="http://hhhhold.com/40x40" alt="头像" class="img-circle">
										<span>乔布斯</span>
									</a>
									<span class="info pull-right">
										交易&nbsp
										<span class="importinfo">50</span>
										&nbsp笔
									</span>
								</div>
								<!--用户列表-->

								<div class="tabuser">
									<a href="#">
										<img src="http://hhhhold.com/40x40" alt="头像" class="img-circle">
										<span>乔布斯</span>
									</a>
									<span class="info pull-right">
										交易&nbsp
										<span class="importinfo">50</span>
										&nbsp笔
									</span>
								</div>
								<!--用户列表-->

							</div>
						</div>

					</div>
					<!--/.sideitemnav-->

				</div>
			</div>
		</div>

	</div>
</div>
</div>
	<footer>
		<div class="container">
			<div class="row hidden-xs">
				<div class="col-md-5 col-sm-5">
					<p> <b>介绍</b>
					</p>
					<p>Logo design by 某某某</p>
					<p>Powerd by ThinkPHP</p>
					<p>Copyright &copy; 2014, 指尖科技-橘子团队</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
				<div class="col-md-5 col-sm-4">
					<p> <b>关于</b>
					</p>
					<p>
						<a target="_blank" href="<?php echo U('Admin/Index/index');?>">橘子团队</a>
					</p>
					<p>
						<a href="mailto:feedback@bigoranger.com">问题反馈</a>
					</p>
					<p>
						<a href="mailto:hi@bigoranger.com">联系我们</a>
					</p>
					<p>
						<a href="#">免责声明</a>
					</p>
				</div>
				<div class="col-md-2 col-sm-3">
					<p>
						<b>客户端下载(android)</b>
					</p>
					<img src="http://hhhhold.com/110x110" alt="客户端二维码下载"></div>
			</div>
			<div class="row visible-xs-inline">
				<div class="col-md-12 text-center text-p">
					<p>
						<a href="<?php echo U('Admin/Index/index');?>">Copyright &copy; 2014, 指尖科技-橘子团队</a>
					</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
			</div>
		</div>
	</footer>
	<script src="/Orange/Public/js/jquery-1.8.0.min.js"></script>
	<script src="/Orange/Public/js/bootstrap.min.js"></script>
	<script src="/Orange/Public/js/juzi.js"></script>

	<!-- 额外js -->	
	
	</body>
	</html>

	<script>
function ajaxclockin() {
    var $btn = $('#clockinbtn').button('loading');
    $.ajax({
        type: 'post',
        cache: false,
        url: $('#clockinform').attr('action'),
        data: $('#clockinform').serialize(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            $btn.button('reset');  
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                $btn.button('reset');
                return false;
            } else {
                showsuccessmsg(data.info, 10, 1000);
                setTimeout(function() {
                    location.reload();
                    $btn.button('reset');
                },
                200);
                return false;
            }                
        }
    });
    return false;
}
$(function() {
    $('#creategoods').click(function(e) {
        var _url = $(this).attr('url');
        location.href = _url;
    });
});

</script>