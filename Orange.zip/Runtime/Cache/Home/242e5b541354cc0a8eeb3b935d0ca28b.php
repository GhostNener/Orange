<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="贵州财经大学-二手交易-以物换物-服务平台-c2c">
	<meta name="author" content="橘子团队">
	<title>大橘子-贵财最大的二手交易平台</title>
	<!-- Bootstrap Core CSS -->
	<link href="/Orange/Public/css/bootstrap.min.css" rel="stylesheet">
	<link href="/Orange/Public/css/normalize.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="/Orange/Public/css/juzi.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Orange/Public/Img/favicon.png"
	type="image/x-icon" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->

	

	<style>
	div.checkbox,
	.photo{

		cursor: pointer;
	}
	.serverok{
		color: #fff;
	}

	.photo{
		position: relative;

	}
	.del{
		position: absolute;
		width: 20px;
		height: 20px;
		line-height: 20px;
		top: 0px;
		right: 0px;
		background-color: #fff;
		border-radius: 100%;
	}
	.rechargebnt{
		display: none;
	}

</style>


</head>
<body>
	<!-- 页身 -->
	<div id="wrap">
		<!-- 导航 -->
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">logo 大橘子</a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="active">
							<a href="<?php echo U('Home/Index/index');?>">首页</a>
						</li>
						<li>
							<a href="#">发现</a>
						</li>
						<li>
							<a href="#">
								礼品
								<span class="navbar-new"></span>
							</a>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search" action="<?php echo U('Home/Index/searchgoods');?>" method="get">
						<div class="input-group">
							<input type="text" class="form-control " id="text" placeholder="搜索商品" name="wd" value="<?php echo ($test); ?>">
							<div class="input-group-btn">
								<button type="submit" class="btn btn-default btn-expend">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
							<!-- /btn-group -->
						</div>
						<!-- /input-group -->
					</form>
					<!-- 登录标识 -->
					<?php if($usermodel == null): ?><ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo U('Usercenter/User/index');?>" >登录</a>
							</li>
							<li>
								<a href="<?php echo U('Usercenter/User/regist');?>">注册</a>
							</li>
						</ul>
						<?php else: ?>
						<!-- 登录状态 -->
						<ul class="nav navbar-nav navbar-right nickul">
							<li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">

									<span class="nickname">
										<img class="img-circle" src="http://hhhhold.com/20x20">&nbsp;<?php echo ($usermodel['Nick']); ?>&nbsp;</span>
									&nbsp
									<span class="caret"></span>
									&nbsp
									<span class="badge">3</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">
											<span class="badge pull-right">3</span>
											未读消息
										</a>
									</li>
									<li>
										<a href="<?php echo U('Usercenter/Index/index');?>">个人中心</a>
									</li>
									<li>
										<a href="#">心愿单</a>
									</li>
									<li>
										<a href="#">充值</a>
									</li>
									<li class="divider"></li>
									<li>
										<a href="<?php echo U('Usercenter/User/logout');?>">退出用户</a>
									</li>
								</ul>
							</li>
						</ul><?php endif; ?>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>


	<div id="main" class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="board">
					<div class="board-inner">
						<!-- 导航 -->
						<ul class="nav nav-tabs" id="myTab">
							<div class="liner"></div>
							<li class="active">
								<a href="#step1" data-toggle="tab" title="基本信息" >
									<span class="round-tabs four"> <i class="glyphicon glyphicon-camera"></i>
									</span>
								</a>
							</li>

							<li>
								<a href="#step2" data-toggle="tab" title="选填内容">
									<span class="round-tabs two"> <i class="glyphicon glyphicon-pencil"></i>
									</span>
								</a>
							</li>
							<li>
								<a href="#step3" data-toggle="tab" title="增值服务">
									<span class="round-tabs three">
										<i class="glyphicon glyphicon-gift"></i>
									</span>
								</a>
							</li>
							<li>
								<a id="tabstep4" href="#step4" data-toggle="tab" title="确认发布">
									<span class="round-tabs one">
										<i class="glyphicon glyphicon-ok"></i>
									</span>
								</a>
							</li>

						</ul>
					</div>
					<!-- 表单内容 -->
					<form class="form-horizontal" id="addgoodsform"  role="form" method="post"  onsubmit="return ajaxsubmit()">
						<div class="tab-content">

							<!-- 必填内容 -->
							<div class="tab-pane fade in active" id="step1">
								<input type="hidden" id="GoodsId" name="GoodsId" value="0">
								<input type="hidden" class="form-control " id="imgcount" name="imgcount" value="0" Readonly>
								<input type="hidden" class="form-control " id="url"	publicurl="/Orange/Public" appurl="/Orange/Home/Goods" rooturl="/Orange" gid="0" saveurl="<?php echo U('Home/Goods/save');?>" urlindex="<?php echo U('Home/Goods/index');?>" homeurl="<?php echo U('Home/Index/index');?>" alowcount="0" computeurl="<?php echo U('Home/Goods/computecost');?>" Readonly>
								<input type="hidden" class="form-control " id="keyid" name="keyid" value="0" Readonly>
								<div class="form-group">
									<label for="Title" class="col-sm-3 control-label">标题</label>
									<div class="col-sm-8">
										<input type="text" id="Title" name="Title" class="form-control" placeholder="输入商品名字、成色"></div>
								</div>
								<div class="form-group">
									<label for="CostPrice" class="col-sm-3 control-label">原价</label>
									<div class="col-sm-3">
										<div class="input-group">
											<input type="text" id="CostPrice" name="CostPrice" class="form-control" placeholder="商品原价">
											<span class="input-group-addon">.00</span>
										</div>
									</div>
								</div>
								<div class="form-group">
									<label for="Price" class="col-sm-3 control-label">转卖价</label>
									<div class="col-sm-3">
										<div class="input-group">
											<input type="text" id="Price" name="Price" class="form-control" placeholder="你要卖的价格">
											<span class="input-group-addon">.00</span>
										</div>
									</div>
								</div>
								<div class="form-group">
									<label for="TradeWay" class="col-sm-3 control-label">交易方式</label>
									<div class="col-sm-3">
										<div class="btn-group" data-toggle="buttons" >
											<label class="btn btn-default btn-expend active" data-toggle="tooltip" data-placement="bottom" title="买家用“金橘”作为货币交易" data-container="body">
												<input type="radio" name="TradeWay" value="1"  autocomplete="off" checked>线上</label>
											<label class="btn btn-default btn-expend"  data-toggle="tooltip" data-placement="bottom" title="现金交易" data-container="body">
												<input type="radio" name="TradeWay"   value="2" autocomplete="off">线下</label>
											<label class="btn btn-default btn-expend" data-toggle="tooltip" data-placement="bottom" title="由买家选择交易方式" data-container="body">
												<input type="radio" name="TradeWay"  value="3" autocomplete="off">线上/线下</label>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="AddressId" class="col-sm-3 control-label">发货联系人</label>
									<div class="col-sm-8">
										<div class="input-group">
											<select class="form-control" id="AddressId" name="AddressId">
												<?php if(is_array($alist)): foreach($alist as $key=>$v): ?><option value="<?php echo ($v['Id']); ?>" address="<?php echo ($v['Address']); ?>" contacts="<?php echo ($v['Contacts']); ?>">
														<?php echo ($v['Contacts']); ?>&nbsp;&nbsp;<?php echo ($v['Tel']); ?>&nbsp;&nbsp;<?php echo ($v['Address']); ?>
													</option><?php endforeach; endif; ?>
											</select>
											<span class="input-group-btn">
												<a id="refreshadd" url="<?php echo U('Home/Goods/refreshadd');?>" class="btn btn-default btn-expend" data-toggle="tooltip" data-placement="top" title="刷新地址" data-container="body">
													<span class="glyphicon glyphicon-refresh"></span>
												</a>
												<a   class="btn btn-default btn-expend"  title="添加新地址" data-container="body" data-toggle="modal" data-target="#addressModal">
													<span class="glyphicon glyphicon-plus"></span>
												</a>
											</span>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="file_upload" class="col-sm-3 control-label">商品照片</label>
									<div class="col-sm-9">
							<!-- 			<input id="file_upload" name="file_upload" type="file" class="btn btn-success" multiple="true"> -->
							<div id="file_upload"></div>
										<div id="image" class=" col-sm-10"></div>
									</div>
								</div>

								<a href="#step2" class="btn btn-danger btn-outline-rounded green active-step pull-right">
									选填内容&nbsp
									<span class="glyphicon glyphicon-chevron-right"></span>
								</a>
							</div>

							<!-- 选填内容 -->
							<div class="tab-pane fade" id="step2">

								<div class="form-group">
									<label for="CategoryId" class="col-sm-3 control-label">商品分类</label>
									<div class="col-sm-5">
										<select class="form-control" id="CategoryId" name="CategoryId">
											<?php if(is_array($clist)): foreach($clist as $key=>$v): ?><option value="<?php echo ($v['Id']); ?>"><?php echo ($v['Title']); ?></option><?php endforeach; endif; ?>
										</select>

									</div>
								</div>

								<div class="form-group">
									<label for="Presentation" class="col-sm-3 control-label">商品描述</label>
									<div class="col-sm-8">
										<textarea class="form-control" id="Presentation" name="Presentation" rows="3" placeholder="详细描述商品信息（选填）"></textarea>
									</div>
								</div>

								<a href="#step1" class="btn btn-primary btn-outline-rounded green active-step">
									<span class="glyphicon glyphicon-chevron-left"></span>
									&nbsp基本信息
								</a>
								<a href="#step3" class="btn btn-orange btn-outline-rounded green active-step pull-right">
									增值服务&nbsp
									<span class="glyphicon glyphicon-chevron-right"></span>
								</a>
							</div>

							<!-- 服务 -->
							<div class="tab-pane fade" id="step3">
								<div class="row">
									<?php if(is_array($slist)): $i = 0; $__LIST__ = $slist;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><!-- 一个服务 -->
										<div class="col-sm-4 col-lg-4 col-md-4 serverdiv">
											<label  style="width:100%">
												<div class="checkbox servercheckbox">
													<input type="checkbox" class="hidden" name="Server[]" price="<?php echo ($v['Price']); ?>" value="<?php echo ($v['Id']); ?>"   >
													<div class="thumbnail">
														<h2 class="text-center"><?php echo ($v['Title']); ?></h2>
														<hr/>
														<div class="caption">
															<p style="font-weight: 400;"><?php echo ($v['Presentation']); ?></p>
														</div>
														<hr/>
														<h4 class="text-right text-p">
															<span class="glyphicon glyphicon-ok pull-left text-success serverok"></span>
															费用:&nbsp
															<span class="importinfo"><?php echo ($v['Price']); ?>.00</span>
														</h4>
													</div>
												</div>
											</label>
										</div>
										<!--一个服务结束--><?php endforeach; endif; else: echo "$empty" ;endif; ?>
								</div>

								<a href="#step2" class="btn btn-danger btn-outline-rounded green active-step">
									<span class="glyphicon glyphicon-chevron-left"></span>
									&nbsp增值服务
								</a>
								<a href="#step4" id="getcostandb" class="btn btn-success btn-outline-rounded green active-step pull-right">
									支付佣金&nbsp
									<span class="glyphicon glyphicon-chevron-right"></span>
								</a>
							</div>
							<div class="tab-pane fade" id="step4" >

								<h3 class="text-center text-import">
									金橘余额:&nbsp
									<span class="importinfo" id="balance"></span>
								</h3>
								<h3 class="text-center text-import">
									共需支付:&nbsp
									<span class="importinfo" id="needpay"></span>
								</h3>
								<!-- 积分不足时候显示 -->
								<p class="text-center text-import rechargebnt">
									<button type="button" class="btn btn-danger " >余额不足请充值</button>
									<a id="refreshblan" class="btn btn-success">
										刷新余额&nbsp;
										<span class="glyphicon glyphicon-refresh"></span>
									</a>
								</p>

								<button type="submit" id="submitsave" class="btn btn-success btn-outline-rounded green active-step pull-right" data-loading-text="发布中..."  autocomplete="off" >
									付款并发布&nbsp
									<span class="glyphicon glyphicon-send"></span>
								</button>
							</div>
							<div class="clearfix"></div>
						</div>
					</form>

					<div class="modal fade" id="addressModal" tabindex="-1" role="dialog" aria-labelledby="addressModalLabel" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">
										<span aria-hidden="true">&times;</span>
										<span class="sr-only">Close</span>
									</button>
									<h4 class="modal-title hightlight" id="addressModalLabel">添加地址</h4>
								</div>
								<form id="addressform" class="form-horizontal" action="<?php echo U('Usercenter/Address/saveaddress');?>" method="post" onsubmit="return ajaxaddresssubmit()">
									<div class="modal-body">
										<input type="hidden" name="modif" value="add">
										<div class="form-group">
											<label for="Contacts" class="col-sm-2 control-label">联系人</label>
											<div class="col-sm-10">
												<input type="tel" name="Contacts" id="Contacts" class="form-control" placeholder="联系人"></div>
										</div>
										<div class="form-group">
											<label for="Tel" class="col-sm-2 control-label">联系电话</label>
											<div class="col-sm-10">
												<input type="tel" name="Tel" id="Tel" class="form-control" placeholder="联系电话"></div>
										</div>
										<div class="form-group">
											<label for="Address" class="col-sm-2 control-label">联系地址</label>
											<div class="col-sm-10">
												<input type="tel" name="Address" id="Address" class="form-control" placeholder="联系地址"></div>
										</div>
										<div class="form-group">
											<div class="col-sm-offset-2 col-sm-10">
												<div class="checkbox">
													<label>
														<input id="IsDefault" name="IsDefault" value="1" type="checkbox">&nbsp;作为默认地址</label>
												</div>
											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-danger" data-dismiss="modal">关闭</button>
										<button id="submitaddress" type="submit" class="btn btn-primary" data-loading-text="提交中..." autocomplete="off" >提交</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<input type="hidden" id="uploadAdapterbaseurl" value="/Orange/Public/js">

</div>
	<footer>
		<div class="container">
			<div class="row hidden-xs">
				<div class="col-md-5 col-sm-5">
					<p> <b>介绍</b>
					</p>
					<p>Logo design by 某某某</p>
					<p>Powerd by ThinkPHP</p>
					<p>Copyright &copy; 2014, 指尖科技-橘子团队</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
				<div class="col-md-5 col-sm-4">
					<p> <b>关于</b>
					</p>
					<p>
						<a target="_blank" href="<?php echo U('Admin/Index/index');?>">橘子团队</a>
					</p>
					<p>
						<a href="mailto:feedback@bigoranger.com">问题反馈</a>
					</p>
					<p>
						<a href="mailto:hi@bigoranger.com">联系我们</a>
					</p>
					<p>
						<a href="#">免责声明</a>
					</p>
				</div>
				<div class="col-md-2 col-sm-3">
					<p>
						<b>客户端下载(android)</b>
					</p>
					<img src="http://hhhhold.com/110x110" alt="客户端二维码下载"></div>
			</div>
			<div class="row visible-xs-inline">
				<div class="col-md-12 text-center text-p">
					<p>
						<a href="<?php echo U('Admin/Index/index');?>">Copyright &copy; 2014, 指尖科技-橘子团队</a>
					</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
			</div>
		</div>
	</footer>
	<script src="/Orange/Public/js/jquery-1.8.0.min.js"></script>
	<script src="/Orange/Public/js/bootstrap.min.js"></script>
	<script src="/Orange/Public/js/juzi.js"></script>

	<!-- 额外js -->	
	
	<script src="/Orange/Public/js/jquery.loadscript.js"></script>
	<script src="/Orange/Public/js/jquery.uploadAdapter.js"></script>
	<script type="text/javascript">/*删除图片  第一个参数为图片父控件的Id  第二个参数为图片相对路径*/
function del(div_id, imgId) {
    var _pdivid = '#' + div_id;
    var _url = $('#url').attr('appurl') + '/delimg';
    $.post(_url, {
        'Id': parseInt(imgId)
    },
    function(data) {
        if (data.info == 1) {
            $(_pdivid).html(data.info);
            $(_pdivid).remove();
            var _imgcount = parseInt($('#imgcount').val());
            if ((_imgcount - 1) <= 0) {
                _imgcount = 0;
            } else {
                _imgcount = _imgcount - 1;
            }
            $('#imgcount').val((_imgcount));
        } else {
            showerrormsg('删除失败!' + data.info, 100, 1000);
        }
    },
    'json');
}

/*保存地址*/
function ajaxaddresssubmit(){
	var $btn = $('#submitaddress').button('loading');
	if(!$.trim($('#Contacts').val())){
		showerrormsg('联系人为空',100,1000);
		$('#Contacts').focus();
		$btn.button('reset');
		return false;
	}
	var isMobile=/^(?:13\d|14\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/; 
	if(!$.trim($('#Tel').val())||!isMobile.test($('#Tel').val())){
		showerrormsg('联系电话不合法',100,1000);
		$('#Tel').focus();
		$btn.button('reset');
		return false;
	}
	if(!$.trim($('#Address').val())){
		showerrormsg('联系地址为空',100,1000);
		$('#Address').focus();
		$btn.button('reset');
		return false;
	}
	$.ajax({
        type: 'post',
        cache: false,
        url: $('#addressform').attr('action'),
        data: $('#addressform').serialize(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            $btn.button('reset');  
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                $btn.button('reset');
                return false;
            } else {
                showsuccessmsg("提交成功", 100, 1000);
                $('#addressform')[0].reset();
                $('#addressModal').modal('hide');
                $btn.button('reset');
                refaddress(false);
                return false;
            }                
        }
    });
    return false;
}
/*保存商品*/
function ajaxsubmit() {

    var $btn = $('#submitsave').button('loading');
    /*	判断是否填写的title*/
    var _Title = $.trim($('#Title').val());
    if (!_Title) {
        showerrormsg('标题不能为空', 100, 1000);
        $btn.button('reset');
        return false;
    }
    /*判断是否填写价格*/
    var _Price = $.trim($('#Price').val());
    if (!$.isNumeric(_Price) || parseInt(_Price) <= 0 || parseInt(_Price) > 999999) {
        showerrormsg('转卖价不合法！1-999999', 100, 1000);
        $btn.button('reset');
        return false;
    }
    /*判断是否填写原价*/
    var _CostPrice = $.trim($('#CostPrice').val());
    if (!$.isNumeric(_CostPrice) || parseInt(_CostPrice) <= 0 || parseInt(_CostPrice) >= 999999) {
        showerrormsg('原价不合法！1-999999', 100, 1000);
        $btn.button('reset');
        return false;
    }
    if (parseInt(_CostPrice) < parseInt(_Price)) {
        showerrormsg('转卖价高于出原价', 100, 1000);
        $btn.button('reset');
        return false;
    }

    $('#GoodsId').val($('#url').attr('gid'));
    /*判断是否传了图*/
    var _imgcount = $('#imgcount').val();
    if (parseInt(_imgcount) <= 0) {
        showerrormsg('你还没上传商品图片呢！', 100, 1000);
        $btn.button('reset');
        return false;
    }
    var _Address = $('#AddressId').val();
    if (!$.isNumeric(_Address) || parseInt(_Address) <= 0) {
        showerrormsg('没有选择分类', 100, 1000);
        $btn.button('reset');
        return false;
    }
    if (!$('#AddressId').val()) {
        showerrormsg('联系人地址为空！', 100, 1000);
        $btn.button('reset');
        return false;
    }
    $.ajax({
        type: 'post',
        cache: false,
        url: $('#url').attr('saveurl'),
        data: $('#addgoodsform').serialize(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            $btn.button('reset');  
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                computecost();
                $btn.button('reset');
                return false;
            } else {
                showsuccessmsg("发布成功", 100, 2000);
                setTimeout(function() {
                    location.href = $('#url').attr('homeurl');
                    $btn.button('reset');
                },
                500);
                return false;
            }                
        }
    });
    return false;

}
function checkdserver() {
    $('.servercheckbox').each(function() {
        var _ch = $(this).children("input").attr('checked');
        if (!_ch) {
            $(this).children('.thumbnail').css('border-color', '#DDD');
            $(this).children('.thumbnail').children('h4').children().first().addClass('serverok');
        } else {
            $(this).children('.thumbnail').css('border-color', '#FA7D3C');
            $(this).children('.thumbnail').children('h4').children().first().removeClass('serverok');

        }
    });
}
/*计算花费*/
function computecost() {
    var _cost = $('#Price').val();
    if (!$.isNumeric(_cost) || parseInt(_cost) <= 0 || parseInt(_cost) > 999999) {
        $('#step4').children().attr('disabled', true);
        $('#balance').html("");
        $('#needpay').html("");
        $('#step4').children().addClass('disabled');
        /*$('#step4').children().children().attr('disabled',true);*/
        $('#step4').children().stop().fadeTo(500, 0.22);

        $('.rechargebnt').hide();
        return false;
    }
    var _se = new Array();
    $('.servercheckbox').each(function() {
        var _ch = $(this).children("input").attr('checked');
        if (!_ch) {} else {
            _se.push(parseInt($(this).children("input").val()));
        }
    });
    $.ajax({
        type: 'post',
        cache: false,
        url: $('#url').attr('computeurl'),
        data: {
            Price: _cost,
            Server: _se
        },
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);             
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                $btn.button('reset');
            } else {
                var _rs = JSON.parse(data.info);
                if (!_rs) {
                    showerrormsg('网络错误', 100, 1000);
                    return false;
                }
                $('#balance').html(_rs['balance'] + '.00');
                 $('#needpay').html(_rs['cost'] + '.00');
                  $('#step4').children().stop().fadeTo(1000, 1);
                  if (parseInt(_rs['cost']) > parseInt(_rs['balance'])) {
                    $('#step4').children().attr('disabled', true);
                    $('#step4').children().children().attr('disabled', false);
                    $('#step4').children().addClass('disabled');
                    $('.rechargebnt').show();
                } else {
                    $('#step4').children().attr('disabled', false);
                    $('#step4').children().removeClass('disabled');
                    $('.rechargebnt').hide();
                }       
            }                
        } 
    });
    return;
}

/*刷新地址*/
function refaddress(isshowmsg) {
    var _url = $('#refreshadd').attr('url');
    $.ajax({
        type: 'post',
        cache: false,
        url: _url,
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                if (isshowmsg) {
                    showerrormsg(data.info, 100, 1000);
                }
                return false;
            } else {
                if (!data.info) {
                    if (isshowmsg) {
                        showerrormsg('刷新失败', 100, 1000);
                    }
                    return;
                }
                var _arr = $.parseJSON(data.info);
                if (!_arr) {
                    if (isshowmsg) {
                        showerrormsg('刷新失败', 100, 1000);
                    }
                    return;
                }
                $('#AddressId').children('option').remove();
                $(_arr).each(function(i, v) {
                    $('#AddressId').append("<option value=" + v['Id'] + " address=" + v['address'] + "contacts=" + v['Contacts'] + " >" + v['Contacts'] + "&nbsp;&nbsp;" + v['Tel'] + "&nbsp;&nbsp;" + v['Address'] + "</option>");
                });
                if (isshowmsg) {
                    showsuccessmsg("刷新成功", 100, 500);
                }
                return;
            }                
        }
    });
}

$(document).ready(function() {
    $('.servercheckbox').click(function(e) {
        var _ch = $(this).children("input").attr('checked');
        if (!_ch) {
            $(this).children('.thumbnail').css('border-color', '#DDD');
            $(this).children('.thumbnail').children('h4').children().first().addClass('serverok');
        } else {
            $(this).children('.thumbnail').css('border-color', '#FA7D3C');
            $(this).children('.thumbnail').children('h4').children().first().removeClass('serverok');

        }
    });

    checkdserver();
    $('#tabstep4').click(function() {
        computecost();
    });
    $('#refreshblan').click(function() {
        computecost();
    });

    $('#refreshadd').click(function(e) {
    	refaddress(true);
    });
    /*标题焦点离开事件  获取分类*/
    $('#Title').blur(function(e) {
        var _Title = $.trim($('#Title').val());
        if (!_Title) {
            return;
        }
        $.post($('#url').attr('appurl') + '/getcategory', {
            'Title': _Title
        },
        function(data) {
            /*收索失败*/
            if (data.status == 0 || !data.status) {
                var _arr = $.parseJSON(data.info);
                /*新的关键字*/
                if (_arr[1] > 1 || parseInt(_arr[1]) > 1) {
                    $('#keyid').val(_arr[1]);
                }
                return;
            }
            /*搜索成功 返回结果*/
            if (data.status == 1 || data.status) {
                var _arr = $.parseJSON(data.info);
                /*返回一个结果的时候 选中返回项*/
                if (parseInt(_arr[0]) == 1) {
                    $('#CategoryId').children('option').each(function() {
                        if (parseInt($(this).val()) == parseInt(_arr[1])) {
                            $(this).attr('selected', true);
                        }
                    });
                    $('#keyid').val(0);
                    return;
                }
                /*返回多个结果  需要先清空 下拉列表 然后重新生成  生成按搜索顺序+剩下的分类顺序  木人选中第一项*/
                if (parseInt(_arr[0]) == 2) {
                    var _arr = $.parseJSON(data.info);
                    $('#CategoryId').children('option').remove();
                    $(_arr[1]).each(function(i, v) {
                        $('#CategoryId').append("<option value=" + v['Id'] + ">" + v['Title'] + "</option>");
                    });
                    $('#keyid').val(0);
                    return;
                }
            }
        },
        'json');
    });
   var up= $('#file_upload').uploadAdapter({
    	auto:true,
/*    	method:'post',//发送请求的方式，get或post*/
		multi:false,//是否允许选择多个文件
        fileTypeDesc: 'Image Files',
        formData: {
            'sname': '<?php echo ($sname); ?>',
            'sid': '<?php echo ($sid); ?>',
            'cid': '<?php echo ($cid); ?>',
            'ckey': '<?php echo ($ckey); ?>'
        },
        fileTypeDesc: '图像文件',
        fileTypeExts: '*.gif; *.jpg; *.png',
        fileSizeLimit: 4096,
        uploader: $('#url').attr('appurl') + '/uploadify',
        //上传路径
        buttonText: '+',
        uploadLimit: 20,
        queueSizeLimi: 20,
        height: 40,
        width: 40,
        /*防止缓存*/
        fileObjName : 'Filedata',
        removeTimeout: 0,
        onFallback: function() {alert('请安装flash player插件');location.href = $('#url').attr('homeurl'); },
/*        onSelectError: function(file, errorCode, errorMsg) {
            var msgText = "上传失败\n";
            switch (errorCode) {
            case - 100 : msgText += "最多上传 " + this.settings.queueSizeLimit + "个文件";;
                break;
            case - 110 : msgText += "文件大小超过限制( " + this.settings.fileSizeLimit + " )";
                break;
            case - 120 : msgText += "文件[" + file.name + "]大小为0";
                break;
            case - 130 : msgText += "文件[" + file.name + "]格式不正确，仅限 " + this.settings.fileTypeExts;
                break;
            default:
                msgText += "错误代码：" + errorCode + "\n" + errorMsg;
                break;
            }
            showerrormsg(msgText, 100, 1000);
        },*/

        onUploadSuccess: function(file, data, response) {
            if (!data) {
                showerrormsg('上传失败！', 100, 1000);
                return;
            }
            data = $.parseJSON(data);
            /*data[0] 图片ID*/
            /*data[1] 图片相对url*/
            if (! ($.isNumeric(data[0])) || !data[0]) {
                showerrormsg('上传失败！' + data[1], 100, 1000);
                return;
            }
            var _gid = $('#url').attr('gid');
            var _postimgurl = $('#url').attr('appurl') + '/saveimg';
            $.post(_postimgurl, {
                '_imgid': data[0],
                '_gid': _gid
            },
            function(datainfo) {
                if (parseInt(datainfo.status) == 1) {
                    /*成功上传返回*/
                    $('#url').attr('gid', datainfo.info);
                    var _imgId = '_' + (parseInt(Math.random() * 100) + (new Date()).valueOf());
                    var _tempPath = $('#url').attr('rooturl');
                    /*插入到image标签内，显示图片的缩略图 */
                    $('#image').append('<div id="' + _imgId + '" class="photo" style="float: left; margin-right: 3px;margin-left: 3px" ><img class="image" src="' + _tempPath + data[1] + '"   /><div class="del" style="text-align: center;"><a title="删除" class="a_imgdel" href="javascript:void(0)"onclick=del("' + _imgId + '","' + data[0] + '");return false; imgurl="' + data[1] + '"><span class="glyphicon glyphicon-remove"></span></a></div></div>');
                    var _imgcount = parseInt($('#imgcount').val());
                    $('#imgcount').val((_imgcount + 1));
                    return;
                } else {
                    showerrormsg('上传失败！', 100, 1000);
                    return;
                }
            });
        }
    });
});
	</script>

	</body>
	</html>