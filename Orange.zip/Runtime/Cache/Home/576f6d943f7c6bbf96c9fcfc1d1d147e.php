<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="贵州财经大学-二手交易-以物换物-服务平台-c2c">
	<meta name="author" content="橘子团队">
	<title>大橘子-贵财最大的二手交易平台</title>
	<!-- Bootstrap Core CSS -->
	<link href="/Orange/Public/css/bootstrap.min.css" rel="stylesheet">
	<link href="/Orange/Public/css/normalize.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="/Orange/Public/css/juzi.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Orange/Public/Img/favicon.png"
	type="image/x-icon" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->

	
	<style>
#embalance{
display: none;
}
	</style>

</head>
<body>
	<!-- 页身 -->
	<div id="wrap">
		<!-- 导航 -->
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">logo 大橘子</a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="active">
							<a href="<?php echo U('Home/Index/index');?>">首页</a>
						</li>
						<li>
							<a href="#">发现</a>
						</li>
						<li>
							<a href="#">
								礼品
								<span class="navbar-new"></span>
							</a>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search" action="<?php echo U('Home/Index/searchgoods');?>" method="get">
						<div class="input-group">
							<input type="text" class="form-control " id="text" placeholder="搜索商品" name="wd" value="<?php echo ($test); ?>">
							<div class="input-group-btn">
								<button type="submit" class="btn btn-default btn-expend">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
							<!-- /btn-group -->
						</div>
						<!-- /input-group -->
					</form>
					<!-- 登录标识 -->
					<?php if($usermodel == null): ?><ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo U('Usercenter/User/index');?>" >登录</a>
							</li>
							<li>
								<a href="<?php echo U('Usercenter/User/regist');?>">注册</a>
							</li>
						</ul>
						<?php else: ?>
						<!-- 登录状态 -->
						<ul class="nav navbar-nav navbar-right nickul">
							<li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">

									<span class="nickname">
										<img class="img-circle" src="http://hhhhold.com/20x20">&nbsp;<?php echo ($usermodel['Nick']); ?>&nbsp;</span>
									&nbsp
									<span class="caret"></span>
									&nbsp
									<span class="badge">3</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">
											<span class="badge pull-right">3</span>
											未读消息
										</a>
									</li>
									<li>
										<a href="<?php echo U('Usercenter/Index/index');?>">个人中心</a>
									</li>
									<li>
										<a href="#">心愿单</a>
									</li>
									<li>
										<a href="#">充值</a>
									</li>
									<li class="divider"></li>
									<li>
										<a href="<?php echo U('Usercenter/User/logout');?>">退出用户</a>
									</li>
								</ul>
							</li>
						</ul><?php endif; ?>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>


	<div id="main" class="container">

		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-orange order-panel">
				<div class="panel-heading">
					<span class="pull-right hidden-xs"><?php echo date('Y-m-d H:i:s',$ordermodel['time']);?></span>
					<span>订单号: <?php echo ($ordermodel['code']); ?></span>
				</div>
				<form id="orderform" action="<?php echo U('Home/Order/createorder');?>" method="post" class="form-horizontal" role="form" onsubmit="return ajaxsubmit">
					<input type="hidden" name="Code" value="<?php echo ($ordermodel['code']); ?>">
					<input type="hidden" name="GoodsId" value="<?php echo ($goods['Id']); ?>">
					<input type="hidden" name="CreateTime" value="<?php echo ($ordermodel['time']); ?>">
					<input type="hidden" id="goodsprice" value="<?php echo ($goods['Price']); ?>">
					<input type="hidden" id="burl" value="<?php echo U('Home/Order/getbalance');?>">
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-2 control-label">商品名</label>
							<div class="col-sm-10">
								<p class="form-control-static"><?php echo ($goods['Title']); ?></p>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">交易方式</label>
							<div class="col-sm-10">
								<div class="btn-group" data-toggle="buttons">
									<?php $__FOR_START_12429__=0;$__FOR_END_12429__=count($tradewaylist);for($i=$__FOR_START_12429__;$i < $__FOR_END_12429__;$i+=1){ if($i == 0): ?><label class="btn btn-default btn-expend active tradewayradio" data-toggle="tooltip" data-placement="bottom" title="<?php echo ($tradewaylist[$i]['msg']); ?>" data-container="body">
												<input type="radio" class="tradewayradio" name="TradeWay" id="option<?php echo ($i+1); ?>" value="<?php echo ($tradewaylist[$i]['id']); ?>" autocomplete="off" checked><?php echo ($tradewaylist[$i]['txt']); ?></label>
											<?php else: ?>
											<label class="btn btn-default btn-expend tradewayradio " data-toggle="tooltip" data-placement="bottom" title="<?php echo ($tradewaylist[$i]['msg']); ?>" data-container="body">
												<input type="radio" class="tradewayradio" name="TradeWay" id="option<?php echo ($i+1); ?>" value="<?php echo ($tradewaylist[$i]['id']); ?>"  autocomplete="off" ><?php echo ($tradewaylist[$i]['txt']); ?></label><?php endif; } ?>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">联系人</label>
							<div class="col-sm-8">
								<div class="input-group">
									<select class="form-control" id="BuyerAddId" name="BuyerAddId">
										<?php if(is_array($useraddress)): foreach($useraddress as $key=>$v): ?><option value="<?php echo ($v['Id']); ?>" address="<?php echo ($v['Address']); ?>" contacts="<?php echo ($v['Contacts']); ?>">
												<?php echo ($v['Contacts']); ?>&nbsp;&nbsp;<?php echo ($v['Tel']); ?>&nbsp;&nbsp;<?php echo ($v['Address']); ?>
											</option><?php endforeach; endif; ?>
									</select>
									<span class="input-group-btn">
										<a id="refreshadd" url="<?php echo U('Home/Goods/refreshadd');?>" class="btn btn-default btn-expend" data-toggle="tooltip" data-placement="top" title="刷新地址" data-container="body">
											<span class="glyphicon glyphicon-refresh"></span>
										</a>
										<a   class="btn btn-default btn-expend"  title="添加新地址" data-container="body" data-toggle="modal" data-target="#addressModal">
											<span class="glyphicon glyphicon-plus"></span>
										</a>
									</span>
								</div>
							</div>
						</div>

					</div>
					<div class="panel-footer">
						<h3 class="text-orange">
							<?php echo ($goods['Price']); ?>.00
							<button id="surebuybtn" class="btn btn-orange pull-right" data-loading-text="处理中..." autocomplete="off">确定购买</button>

						</h3>

						<!-- 选择线上交易的时候显示余额 -->
						<span id="embalance">
							金橘余额:
							<span class="text-orange">.00</span>
							<button id="refbalance" type="button" class="btn btn-success btn-xs" title="刷新余额">
								<span class="glyphicon glyphicon-refresh"></span>
							</button>
							<button id="rechargebtn" type="button" class="btn btn-danger btn-xs" >余额不足请充值</button>
						</span>
					</div>
				</form>

				<div class="modal fade" id="addressModal" tabindex="-1" role="dialog" aria-labelledby="addressModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">
									<span aria-hidden="true">&times;</span>
									<span class="sr-only">Close</span>
								</button>
								<h4 class="modal-title hightlight" id="addressModalLabel">添加地址</h4>
							</div>
							<form id="addressform" class="form-horizontal" action="<?php echo U('Usercenter/Address/saveaddress');?>" method="post" onsubmit="return ajaxaddresssubmit()">
								<div class="modal-body">
									<input type="hidden" name="modif" value="add">
									<div class="form-group">
										<label for="Contacts" class="col-sm-2 control-label">联系人</label>
										<div class="col-sm-10">
											<input type="tel" name="Contacts" id="Contacts" class="form-control" placeholder="联系人"></div>
									</div>
									<div class="form-group">
										<label for="Tel" class="col-sm-2 control-label">联系电话</label>
										<div class="col-sm-10">
											<input type="tel" name="Tel" id="Tel" class="form-control" placeholder="联系电话"></div>
									</div>
									<div class="form-group">
										<label for="Address" class="col-sm-2 control-label">联系地址</label>
										<div class="col-sm-10">
											<input type="tel" name="Address" id="Address" class="form-control" placeholder="联系地址"></div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-2 col-sm-10">
											<div class="checkbox">
												<label>
													<input id="IsDefault" name="IsDefault" value="1" type="checkbox">&nbsp;作为默认地址</label>
											</div>
										</div>
									</div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-danger" data-dismiss="modal">关闭</button>
									<button id="submitaddress" type="submit" class="btn btn-primary" data-loading-text="提交中..." autocomplete="off" >提交</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
	<footer>
		<div class="container">
			<div class="row hidden-xs">
				<div class="col-md-5 col-sm-5">
					<p> <b>介绍</b>
					</p>
					<p>Logo design by 某某某</p>
					<p>Powerd by ThinkPHP</p>
					<p>Copyright &copy; 2014, 指尖科技-橘子团队</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
				<div class="col-md-5 col-sm-4">
					<p> <b>关于</b>
					</p>
					<p>
						<a target="_blank" href="<?php echo U('Admin/Index/index');?>">橘子团队</a>
					</p>
					<p>
						<a href="mailto:feedback@bigoranger.com">问题反馈</a>
					</p>
					<p>
						<a href="mailto:hi@bigoranger.com">联系我们</a>
					</p>
					<p>
						<a href="#">免责声明</a>
					</p>
				</div>
				<div class="col-md-2 col-sm-3">
					<p>
						<b>客户端下载(android)</b>
					</p>
					<img src="http://hhhhold.com/110x110" alt="客户端二维码下载"></div>
			</div>
			<div class="row visible-xs-inline">
				<div class="col-md-12 text-center text-p">
					<p>
						<a href="<?php echo U('Admin/Index/index');?>">Copyright &copy; 2014, 指尖科技-橘子团队</a>
					</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
			</div>
		</div>
	</footer>
	<script src="/Orange/Public/js/jquery-1.8.0.min.js"></script>
	<script src="/Orange/Public/js/bootstrap.min.js"></script>
	<script src="/Orange/Public/js/juzi.js"></script>

	<!-- 额外js -->	
	
	<script>
/*保存地址*/
function ajaxaddresssubmit(){
	var $btn = $('#submitaddress').button('loading');
	if(!$.trim($('#Contacts').val())){
		showerrormsg('联系人为空',100,1000);
		$('#Contacts').focus();
		$btn.button('reset');
		return false;
	}
	var isMobile=/^(?:13\d|14\d|15\d|18\d)\d{5}(\d{3}|\*{3})$/; 
	if(!$.trim($('#Tel').val())||!isMobile.test($('#Tel').val())){
		showerrormsg('联系电话不合法',100,1000);
		$('#Tel').focus();
		$btn.button('reset');
		return false;
	}
	if(!$.trim($('#Address').val())){
		showerrormsg('联系地址为空',100,1000);
		$('#Address').focus();
		$btn.button('reset');
		return false;
	}
	$.ajax({
        type: 'post',
        cache: false,
        url: $('#addressform').attr('action'),
        data: $('#addressform').serialize(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            $btn.button('reset');  
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                $btn.button('reset');
                return false;
            } else {
                showsuccessmsg("提交成功", 100, 1000);
                $('#addressform')[0].reset();
                $('#addressModal').modal('hide');
                $btn.button('reset');
                refaddress(false);
                return false;
            }                
        }
    });
    return false;
}
/*刷新地址*/
function refaddress(isshowmsg) {
    var _url = $('#refreshadd').attr('url');
    $.ajax({
        type: 'post',
        cache: false,
        url: _url,
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                if (isshowmsg) {
                    showerrormsg(data.info, 100, 1000);
                }
                return false;
            } else {
                if (!data.info) {
                    if (isshowmsg) {
                        showerrormsg('刷新失败', 100, 1000);
                    }
                    return;
                }
                var _arr = $.parseJSON(data.info);
                if (!_arr) {
                    if (isshowmsg) {
                        showerrormsg('刷新失败', 100, 1000);
                    }
                    return;
                }
                $('#BuyerAddId').children('option').remove();
                $(_arr).each(function(i, v) {
                    $('#BuyerAddId').append("<option value=" + v['Id'] + " address=" + v['address'] + "contacts=" + v['Contacts'] + " >" + v['Contacts'] + "&nbsp;&nbsp;" + v['Tel'] + "&nbsp;&nbsp;" + v['Address'] + "</option>");
                });
                if (isshowmsg) {
                    showsuccessmsg("刷新成功", 100, 500);
                }
                return;
            }                
        }
    });
}
/*获取余额*/
function getbalance(isshowmsg){
    $.ajax({
        type: 'post',
        cache: false,
        url: $('#burl').val(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            return false;              
        },
         success:  
        function(data)  {
            if (data.status == 0) {
                if (isshowmsg) {
                    showerrormsg(data.info, 100, 1000);
                }
                return false;
            } else {
            	if(isshowmsg){showsuccessmsg('刷新余额成功',100,500);}
            	$('#embalance').children('span').html(data.info+'.00');
            	$('#embalance').show();
            	var _b=parseInt(data.info);
            	if($('#goodsprice').val()>_b){
            		$('#rechargebtn').show();
            		$('#surebuybtn').attr('disabled',true);
            	}else{
            		$('#rechargebtn').hide();
            		$('#surebuybtn').attr('disabled',false);
            	}
            }                
        }
    });
}
/*初始化检查是不是线上*/
function checktradway() {
    $('input:radio:checked').each(function() {
        if ($(this).val() == 1 && $(this).attr('checked')) {
            getbalance(false);
            return true;
        }
    });
}
/*购买*/
function ajaxsubmit(){
	var $btn = $('#surebuybtn').button('loading');
}
$(function() {
	$('.tradewayradio').click(function(e){
		var _id=$(this).children().val();
		if(_id==1){
			getbalance(false);
		}else{
			$('#embalance').hide();
            $('#surebuybtn').attr('disabled',false);
		}
	})
    $('#refreshadd').click(function(e) {
        refaddress(true);
    });
    $('#refbalance').click(function(e) {
        getbalance(true);
    });
    checktradway();
})
	</script>

	</body>
	</html>