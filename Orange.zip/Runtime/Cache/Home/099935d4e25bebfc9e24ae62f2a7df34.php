<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="description" content="贵州财经大学-二手交易-以物换物-服务平台-c2c">
	<meta name="author" content="橘子团队">
	<title>大橘子-贵财最大的二手交易平台</title>
	<!-- Bootstrap Core CSS -->
	<link href="/Orange/Public/css/bootstrap.min.css" rel="stylesheet">
	<link href="/Orange/Public/css/normalize.css" rel="stylesheet">
	<!-- Custom CSS -->
	<link href="/Orange/Public/css/juzi.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Orange/Public/Img/favicon.png"
	type="image/x-icon" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->

	
		<link href="/Orange/Public/css/jquery.fancybox.css" rel="stylesheet">	
		<link href="/Orange/Public/css/jquery.fancybox-thumbs.css" rel="stylesheet">
</head>
<body>
	<!-- 页身 -->
	<div id="wrap">
		<!-- 导航 -->
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">logo 大橘子</a>
				</div>

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="active">
							<a href="<?php echo U('Home/Index/index');?>">首页</a>
						</li>
						<li>
							<a href="#">发现</a>
						</li>
						<li>
							<a href="#">
								礼品
								<span class="navbar-new"></span>
							</a>
						</li>
					</ul>
					<form class="navbar-form navbar-left" role="search" action="<?php echo U('Home/Index/searchgoods');?>" method="get">
						<div class="input-group">
							<input type="text" class="form-control " id="text" placeholder="搜索商品" name="wd" value="<?php echo ($test); ?>">
							<div class="input-group-btn">
								<button type="submit" class="btn btn-default btn-expend">
									<span class="glyphicon glyphicon-search"></span>
								</button>
							</div>
							<!-- /btn-group -->
						</div>
						<!-- /input-group -->
					</form>
					<!-- 登录标识 -->
					<?php if($usermodel == null): ?><ul class="nav navbar-nav navbar-right">
							<li>
								<a href="<?php echo U('Usercenter/User/index');?>" >登录</a>
							</li>
							<li>
								<a href="<?php echo U('Usercenter/User/regist');?>">注册</a>
							</li>
						</ul>
						<?php else: ?>
						<!-- 登录状态 -->
						<ul class="nav navbar-nav navbar-right nickul">
							<li class="dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">

									<span class="nickname">
										<img class="img-circle" src="http://hhhhold.com/20x20">&nbsp;<?php echo ($usermodel['Nick']); ?>&nbsp;</span>
									&nbsp
									<span class="caret"></span>
									&nbsp
									<span class="badge">3</span>
								</a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">
											<span class="badge pull-right">3</span>
											未读消息
										</a>
									</li>
									<li>
										<a href="<?php echo U('Usercenter/Index/index');?>">个人中心</a>
									</li>
									<li>
										<a href="#">心愿单</a>
									</li>
									<li>
										<a href="#">充值</a>
									</li>
									<li class="divider"></li>
									<li>
										<a href="<?php echo U('Usercenter/User/logout');?>">退出用户</a>
									</li>
								</ul>
							</li>
						</ul><?php endif; ?>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>


		<div id="main" class="container">
			<!-- 购买按钮 -->	
			<div class="navbar-fixed-bottom fixed-expand">
				<form action="<?php echo U('Home/Order/index');?>" method="post" role="form">
					<input type="hidden" name="Id" value="<?php echo ($goods['Id']); ?>">	
					<button  type="submit" class="btn btn-orange btnpublish"  title="立即购买">
						<span class="glyphicon glyphicon-shopping-cart"></span>
					</button>
				</form>
			</div>
			<!-- mobile端显示固定导航 -->	
			<div class="col-md-3 visible-xs-block">
				<div class="panel panel-default">
					<div class="panel-body detail-panel">
						<h4><?php echo ($goods["Title"]); ?></h4>
						<h2 class="importinfo">
							<?php echo ($goods["Price"]); ?>.00
							<span class="oldprice"><?php echo ($goods["CostPrice"]); ?>.00</span>
						</h2>

						<hr/>	
						<div class="row">
							<div class="col-md-5">交易方式</div>
							<div class="col-md-7"><?php echo ($goods["TradeWayTxt"]); ?></div>
						</div>
						<hr/>	
						<button class="btn btn-danger">
							<span class="glyphicon glyphicon-heart"></span>
							&nbsp心愿单
						</button>
						<?php if((($usermodel == null) or ($usermodel['Id'] == null))): ?><a href="<?php echo U('Usercenter/User/index');?>"  class="btn btn-primary " >
								<span class="glyphicon glyphicon-comment"></span>
								&nbsp留言
							</a>
							<?php else: ?>	
							<button  class="btn btn-primary pubcomments" data-toggle="modal" data-target="#refModal">
								<span class="glyphicon glyphicon-comment"></span>
								&nbsp留言
							</button><?php endif; ?>
					</div>
				</div>
			</div>
			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-body">

						<!-- Slider -->	
						<div class="row">
							<div class="col-xs-12" id="slider">
								<!-- Top part of the slider -->	
								<div id="carousel-bounding-box" data-toggle="tooltip" data-placement="top" title="点击查看原图" data-container="body" data-delay="500">
									<div class="carousel slide" id="myCarousel">
										<!-- Carousel items -->	
										<div class="carousel-inner">
											<?php $__FOR_START_11473__=0;$__FOR_END_11473__=$imgcount;for($i=$__FOR_START_11473__;$i < $__FOR_END_11473__;$i+=1){ if($i == 0): ?><div class="active item" data-slide-number="<?php echo ($i); ?>">
														<a class="fancybox-thumbs" data-fancybox-group="thumb" href="/Orange<?php echo ($goodsimg[$i]['URL']); ?>">
															<?php if(checkfile_exists($goodsimg[$i]['MD_URL']) == 1): ?><img src="/Orange<?php echo ($goodsimg[$i]['MD_URL']); ?>" alt="<?php echo ($goodsimg[$i]['Title']); ?>" />	
																<?php else: ?>	
																<img src="/Orange<?php echo getdefaultimg(2);?>" alt="<?php echo ($goodsimg[$i]['Title']); ?>" /><?php endif; ?>
														</a>
													</div>
													<?php else: ?>	
													<div class=" item" data-slide-number="<?php echo ($i); ?>">
														<a class="fancybox-thumbs" data-fancybox-group="thumb" href="/Orange<?php echo ($goodsimg[$i]['URL']); ?>">
															<?php if(checkfile_exists($goodsimg[$i]['MD_URL']) == 1): ?><img src="/Orange<?php echo ($goodsimg[$i]['MD_URL']); ?>" alt="<?php echo ($goodsimg[$i]['Title']); ?>" />	
																<?php else: ?>	
																<img src="/Orange<?php echo getdefaultimg(2);?>" alt="<?php echo ($goodsimg[$i]['Title']); ?>" /><?php endif; ?>
														</a>
													</div><?php endif; } ?>
										</div>
										<!-- Carousel nav -->	
										<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
											<span class="glyphicon glyphicon-chevron-left"></span>
										</a>
										<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
											<span class="glyphicon glyphicon-chevron-right"></span>
										</a>
									</div>
								</div>
							</div>
						</div>
						<!--/Slider-->	
						<div class="row hidden-xs" id="slider-thumbs">
							<!-- Bottom switcher of slider -->	
							<ul class="hide-bullets">
								<?php $__FOR_START_29494__=0;$__FOR_END_29494__=$imgcount;for($i=$__FOR_START_29494__;$i < $__FOR_END_29494__;$i+=1){ ?><li class="col-sm-2">
										<a href="#" class="thumbnail" id="carousel-selector-<?php echo ($i); ?>">
											<?php if(checkfile_exists($goodsimg[$i]['ThumbURL']) == 1): ?><img src="/Orange<?php echo ($goodsimg[$i]['ThumbURL']); ?>">	
												<?php else: ?>	
												<img src="/Orange<?php echo getdefaultimg(1);?>"  /><?php endif; ?>
										</a>
									</li><?php } ?>
							</ul>
						</div>

						<hr/>	

						<!-- 描述 -->	
						<div class="row">

							<div class="col-md-12">
								<h4 class="pull-right message"><?php echo date('Y-m-d H:i:s',$goods['CreateTime']);?></h4>
								<a href="#">
									<img src="/Orange<?php echo ($goods['avatarURL']); ?>" alt="头像" class="img-circle">	
									<span><?php echo ($goods['Nick']); ?></span>
								</a>
								<span>Lv</span>
								<span class="importinfo"><?php echo ($goods['Grade']); ?></span>
							</div>

							<div class="col-md-12">
								<p class="detail-p"><?php echo ($goods['Presentation']); ?></p>
							</div>

						</div>
					</div>
				</div>

				<!-- 评论列表 -->	
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="row">

							<div class="timeline-centered">
								<?php if(is_array($commentlist)): $i = 0; $__LIST__ = $commentlist;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><article class="timeline-entry">
										<div class="timeline-entry-inner">
											<div class="timeline-icon">
												<img src="/Orange<?php echo ($v['CriticsURL']); ?>" alt="头像" class="img-circle"></div>

											<div class="timeline-label">
												<span class="pull-right time"><?php echo ($v['CreateTime']); ?></span>
												<h2>
													<a href="#"><?php echo ($v['Critics']); ?></a>
													<?php if((($v['UserId'] == $v['AssesseeId']) or ($v['AssesseeId'] == null)) or ($v['AssesseeId'] == 0)): else: ?>	
														<span>回复</span>

														<a href="#"><?php echo ($v['Reply']); ?></a><?php endif; ?>
												</h2>
												<p class="content"><?php echo ($v['Content']); ?></p>
												<?php if((($usermodel == null) or ($usermodel['Id'] == null))): ?><a href="<?php echo U('Usercenter/User/index');?>"  class="replay " >回复</a>
													<?php else: ?>	
													<a href="javascript:void(0)" uid="<?php echo ($v['UserId']); ?>" nick="<?php echo ($v['Critics']); ?>" class="replay" data-toggle="modal" data-target="#refModal">回复</a><?php endif; ?>
											</div>
										</div>
									</article><?php endforeach; endif; else: echo "$empty" ;endif; ?>
							</div>

						</div>
					</div>
				</div>

				<div class="modal fade" id="refModal" tabindex="-1" role="dialog" aria-labelledby="refModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">
									<span aria-hidden="true">&times;</span>
									<span class="sr-only">Close</span>
								</button>
								<h4 class="modal-title hightlight" id="refModalLabel">留言</h4>
							</div>
							<form id="refform" class="form-horizontal" action="<?php echo U('Home/Index/addComment');?>" method="post" onsubmit="return ajaxsubmit()">
								<div class="modal-body">
									<input type="hidden" name="GoodsId" value="<?php echo ($goods['Id']); ?>" />	
									<input type="hidden" name="AssesseeId" id="AssesseeId" value="0" />	
									<input type="hidden" name="UserId" id="UserId" value="<?php echo ($usermodel['Id']); ?>" />	
									<div class="form-group">
										<label for="Content" class="col-sm-2 control-label">内容</label>
										<div class="col-sm-10">
											<textarea id="Content" name="Content" class="form-control" rows="3" placeholder="内容"></textarea>
										</div>
									</div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-danger" data-dismiss="modal">关闭</button>
									<button id="submitref" type="submit" class="btn btn-primary" data-loading-text="提交中..." autocomplete="off" >提交</button>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
			<!-- web端显示的是浮动导航 -->	
			<div class="col-md-3 hidden-xs">
				<div class="panel panel-default" data-spy="affix">
					<div class="panel-body detail-panel">
						<h4><?php echo ($goods["Title"]); ?></h4>
						<h2 class="importinfo">
							<?php echo ($goods["Price"]); ?>.00
							<span class="oldprice"><?php echo ($goods["CostPrice"]); ?>.00</span>
						</h2>

						<hr/>	
						<div class="row">
							<div class="col-md-5">交易方式</div>
							<div class="col-md-7"><?php echo ($goods["TradeWayTxt"]); ?></div>
						</div>
						<hr/>	
						<button class="btn btn-danger">
							<span class="glyphicon glyphicon-heart"></span>
							&nbsp心愿单
						</button>
						<?php if((($usermodel == null) or ($usermodel['Id'] == null))): ?><a href="<?php echo U('Usercenter/User/index');?>" class="btn btn-primary " >
								<span class="glyphicon glyphicon-comment"></span>
								&nbsp留言
							</a>
							<?php else: ?>	
							<button  class="btn btn-primary pubcomments" data-toggle="modal" data-target="#refModal">
								<span class="glyphicon glyphicon-comment"></span>
								&nbsp留言
							</button><?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	
</div>
	<footer>
		<div class="container">
			<div class="row hidden-xs">
				<div class="col-md-5 col-sm-5">
					<p> <b>介绍</b>
					</p>
					<p>Logo design by 某某某</p>
					<p>Powerd by ThinkPHP</p>
					<p>Copyright &copy; 2014, 指尖科技-橘子团队</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
				<div class="col-md-5 col-sm-4">
					<p> <b>关于</b>
					</p>
					<p>
						<a target="_blank" href="<?php echo U('Admin/Index/index');?>">橘子团队</a>
					</p>
					<p>
						<a href="mailto:feedback@bigoranger.com">问题反馈</a>
					</p>
					<p>
						<a href="mailto:hi@bigoranger.com">联系我们</a>
					</p>
					<p>
						<a href="#">免责声明</a>
					</p>
				</div>
				<div class="col-md-2 col-sm-3">
					<p>
						<b>客户端下载(android)</b>
					</p>
					<img src="http://hhhhold.com/110x110" alt="客户端二维码下载"></div>
			</div>
			<div class="row visible-xs-inline">
				<div class="col-md-12 text-center text-p">
					<p>
						<a href="<?php echo U('Admin/Index/index');?>">Copyright &copy; 2014, 指尖科技-橘子团队</a>
					</p>
					<p>
						<a href="http://www.miibeian.gov.cn/">黔ICP备14004869号-1</a>
					</p>
				</div>
			</div>
		</div>
	</footer>
	<script src="/Orange/Public/js/jquery-1.8.0.min.js"></script>
	<script src="/Orange/Public/js/bootstrap.min.js"></script>
	<script src="/Orange/Public/js/juzi.js"></script>

	<!-- 额外js -->	
	

		<script src="/Orange/Public/js/jquery.fancybox.pack.js"></script>
		<script src="/Orange/Public/js/jquery.fancybox-thumbs.js"></script>
		<script>
function ajaxsubmit() {
    var $btn = $('#submitref').button('loading');
    if (!$.trim($('#Content').val())) {
        showerrormsg('内容不能为空', 100, 1000);
        $('#Content').focus();
        $btn.button('reset');
        return false;
    }
    $.ajax({
        type: 'post',
        cache: false,
        url: $('#refform').attr('action'),
        data: $('#refform').serialize(),
        error:  
        function(request)  {
            showerrormsg('网络错误', 100, 1000);
            $btn.button('reset');   
            return false;             
        },
                        success:  
        function(data)  {
            if (data.status == 0) {
                showerrormsg(data.info, 100, 1000);
                $btn.button('reset');
                return false;
            } else {
                showsuccessmsg("提交成功", 100, 2000);
                setTimeout(function() {
                    $btn.button('reset');
                    location.reload();
                },
                300);
                return false;
            }                
        }
    });
    return false;
}
$(document).ready(function() {
    $('.replay').click(function() {
        if ($(this).attr('uid') == $('#UserId').val()) {
        	$('#refModalLabel').html('留言');
            $('#AssesseeId').val('0');
        } else {
            $('#AssesseeId').val($(this).attr('uid'));
            $('#refModalLabel').html('回复&nbsp;<a>' + $(this).attr('nick') + '</a>');
        }

    });

    $('.pubcomments').click(function() {
        $('#refModalLabel').html('留言');
        $('#AssesseeId').val('0');
    });

    $('.fancybox').fancybox();
    $('.fancybox-thumbs').fancybox({
        prevEffect: 'none',
        nextEffect: 'none',

        closeBtn: false,
        arrows: false,
        nextClick: true,

        helpers: {
            thumbs: {
                width: 50,
                height: 50
            }
        }
    });
});
		</script>
	
	</body>
	</html>